package sk.tabletgps;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;

/**
 * Tablet GPS pre FS22 - zobrazuje GPS obrazovku (assets/tablet.html),
 * ktora berie data zo servera TabletGPS na PC cez domacu Wi-Fi.
 */
public class MainActivity extends Activity {

    private static final String SETUP_URL = "file:///android_asset/tablet.html";
    private WebView web;
    private volatile boolean forceSetup = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(13, 18, 23));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setMediaPlaybackRequiresUserGesture(true);

        web.setWebChromeClient(new WebChromeClient());   // zobrazi confirm/prompt dialogy
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                // PC neodpoveda pri nacitani obrazovky -> spat na pripojenie
                if (request.isForMainFrame() && !SETUP_URL.equals(view.getUrl())) {
                    view.loadUrl(SETUP_URL);
                }
            }
        });
        web.addJavascriptInterface(new Bridge(), "TabletGPSApp");
        web.loadUrl(SETUP_URL);

        hideSystemUi();
    }

    /** Funkcie dostupne z JavaScriptu ako window.TabletGPSApp */
    public class Bridge {
        @JavascriptInterface
        public String localIp() {
            try {
                for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                    if (!ni.isUp() || ni.isLoopback()) continue;
                    for (InetAddress addr : Collections.list(ni.getInetAddresses())) {
                        if (addr instanceof Inet4Address && addr.isSiteLocalAddress()) {
                            return addr.getHostAddress();
                        }
                    }
                }
            } catch (Exception ignored) {
            }
            return "";
        }

        @JavascriptInterface
        public String version() {
            return "1.1";
        }

        /** Otvori obrazovku pripojenia k PC (tlacidlo Server). */
        @JavascriptInterface
        public void openSetup() {
            forceSetup = true;
            runOnUiThread(() -> web.loadUrl(SETUP_URL));
        }

        /** Vrati true raz po stlaceni Server - vtedy sa nepripaja automaticky. */
        @JavascriptInterface
        public boolean consumeForceSetup() {
            boolean f = forceSetup;
            forceSetup = false;
            return f;
        }
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }
}
